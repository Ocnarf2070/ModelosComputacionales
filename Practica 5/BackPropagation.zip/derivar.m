function [Y]=derivar(X)
         Y=X.*(1-X);