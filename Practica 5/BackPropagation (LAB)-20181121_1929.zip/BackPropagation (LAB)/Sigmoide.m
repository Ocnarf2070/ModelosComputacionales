function [Y]=Sigmoide(X)

%         Y=1./(1+exp(-2*X));
        Y=1./(1+exp(-X));